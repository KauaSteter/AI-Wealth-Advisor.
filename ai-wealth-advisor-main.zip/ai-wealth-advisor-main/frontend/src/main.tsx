import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { PreferencesEffects } from './components/system/PreferencesEffects';
import { SessionBoundary } from './components/system/SessionBoundary';
import App from './App';
import { initializeDemoData } from './services/demo/bootstrap';
import { AuthProvider } from './store/authStore';
import './index.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

if (import.meta.env.VITE_APP_MODE === 'demo') initializeDemoData();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <PreferencesEffects>
        <BrowserRouter>
          <AuthProvider>
            <SessionBoundary>
              <App />
            </SessionBoundary>
          </AuthProvider>
        </BrowserRouter>
      </PreferencesEffects>
    </QueryClientProvider>
  </React.StrictMode>
);
